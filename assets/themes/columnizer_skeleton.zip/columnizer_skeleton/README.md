columnizer_skeleton
===================

Simple columnizer theme to use as a starting point